const Colors = {
    primary500: "#356fa9ee",
    primary800: "#27517bee",
    accent500: "lightgray",
    accent800: "gray",
}

export default Colors;